
package model;

/**
 * Esta clase representa un trabajador de la empresa
 * Llanquihue Tour.
 * 
 * Esta clase hereda de la clase Persona
 */
public class Trabajador extends Persona {
    
    // 1. Crear atributos propios de la clase.
    
    private String cargo;
    
    // 2. Crear constructor de la clase Trabajador.

    /**
     * Comstructor de la clase Trabajador
     * 
     * @param cargo Representa el puesto de trabajo del trabajador.
     * @param nombre Representa el nombre del trabajador.
     * @param edad Representa la edad del trabajador.
     * @param direccion Representa la direccion del trabajador.
     */

    public Trabajador(String cargo, String nombre, int edad, Direccion direccion) {
        super(nombre, edad, direccion);
        this.cargo = cargo;
    }
    
    // 3. Crear Getters y Setters.

    public String getCargo() {
        return cargo;
    }

    public void setCargo(String cargo) {
        this.cargo = cargo;
    }
    
    
    // 4. Crear toString() con @Override.
    
    /**
     * 
     * @return los datos del trabajador en forma de texto. 
     */
    
    @Override
    public String toString(){
        return super.toString() +
                "Cargo: " + cargo;
    }
    
        
}
