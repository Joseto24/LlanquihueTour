
package model;

/**
 *Esta clase representa a un cliente de 
 * la empresa Llanquihue Tour. 
 * 
 * Esta clase hereda de la clase Persona.
 */
public class Cliente extends Persona{
    
    // 1. Crear atributo propio de la clase.
    
    private String servicio;
    
    // 2. Crear constructor de la clase Cliente.

    /**
     * Constructor de la clase Cliente.
     * 
     * @param servicio Representa el servicio que adquiere el cliente
     * @param nombre Representa el nombre del cliente.
     * @param edad Representa la edad del cliente.
     * @param direccion Representa la direccion del cliente.
     */
    
    public Cliente(String servicio, String nombre, int edad, Direccion direccion) {
        super(nombre, edad, direccion);
        this.servicio = servicio;
    }
    
    // 3. Crear Getters y Setters.

    public String getServicio() {
        return servicio;
    }

    public void setServicio(String servicio) {
        this.servicio = servicio;
    }
    
    // 4. Crear toString() con @Override().
    
    @Override
    public String toString(){
        return super.toString() + 
                "Tipo de Servicio: " + servicio;
    }
    
}
