
package model;

/** Esta clase representa la direccion de una Persona.
 *
 * Esta clase se utiliza como composicion para la
 * clase Persona.
 */
public class Direccion {
    
    // 1. Crear atributos para la clase.
    
    private String calle;
    private int numero;
    private String ciudad;
    private String region;
    
    
    // 2. Crear constructor.

    /**
     * Constructor de la clase Direccion.
     * 
     * @param calle Representa el nombre de la calle en la que vive la persona.
     * @param numero Representa el numero de la calle en la que vive la persona.
     * @param ciudad Representa el nombre de la ciudad en la que vive la persona.
     * @param region Representa el nombre de la region en la que vive el persona.
     */
    
    public Direccion(String calle, int numero, String ciudad, String region) {
        this.calle = calle;
        this.numero = numero;
        this.ciudad = ciudad;
        this.region = region;
    }
    
    // 3. Crear los Getters y Setters.

    public String getCalle() {
        return calle;
    }

    public void setCalle(String Calle) {
        this.calle = Calle;
    }

    public int getNumero() {
        return numero;
    }

    public void setNumero(int numero) {
        this.numero = numero;
    }

    public String getCiudad() {
        return ciudad;
    }

    public void setCiudad(String ciudad) {
        this.ciudad = ciudad;
    }

    public String getRegion() {
        return region;
    }

    public void setRegion(String region) {
        this.region = region;
    }
    
    
    // 4. Crear toString() con @Override.
    
    /**
     * 
     * @return los datos de la direccion en forma de texto.
     */
    
    @Override
    
    public String toString(){
        return "Direccion: " + calle + numero + ", " + ciudad + ", " + region;
    }
    
    
    
}
