
package model;

/**
 * Esta clase representa una persona.
 * 
 * Utiliza como composicion la clase Direccion.
 */
public class Persona {
    
    // 1. Crear los atributos de la Clase.
    
    private String nombre;
    private int edad;
    
    // 2. composicion clase Direccion.
    
    private Direccion direccion;
    
    // 3. Crear constructor.

    /**
     * Constructor  de la clase Persona.
     * 
     * @param nombre Representa el nombre de la persona.
     * @param edad Representa la edad de la persona.
     * @param direccion Representa la direccion de la persona.
     */
    
    public Persona(String nombre, int edad, Direccion direccion) {
        this.nombre = nombre;
        this.edad = edad;
        this.direccion = direccion;
    }
    
    // 4. Crear Getters y Setters.

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public int getEdad() {
        return edad;
    }

    public void setEdad(int edad) {
        this.edad = edad;
    }

    public Direccion getDireccion() {
        return direccion;
    }

    public void setDireccion(Direccion direccion) {
        this.direccion = direccion;
    }
    
    // 5. Crear toString() con @Override.
    
    /**
     * 
     * @return los datos de la persona en forma de texto. 
     */
    
    @Override
    public String toString(){
            return "\nNombre: " + nombre +
                    "\nEdad: " + edad + 
                    "\nDireccion: " + direccion + "\n";
    }
    
    
    
    
}
