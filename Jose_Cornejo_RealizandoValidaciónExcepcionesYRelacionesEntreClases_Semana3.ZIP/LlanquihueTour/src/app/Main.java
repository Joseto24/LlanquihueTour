
package app;

import model.Cliente;
import model.Direccion;
import model.Persona;
import model.Trabajador;

/**
 *
 * @author Xoma
 */
public class Main {

    public static void main(String[] args) {       
       
        Direccion direccionP = new Direccion("Los Acacios", 106, "Concepcion", "Region del BioBio");
        Direccion direccionC = new Direccion("Pedro aguirre", 505, "Rancagua", "Region del libertador");
        Direccion direccionT = new Direccion("Santa teresita", 97, "Valdivia", "Region de los rios");
        Persona persona1 = new Persona("Jose", 24, direccionP);
        Cliente cliente1 = new Cliente("Rafting", "Ignacio Sepulveda", 19, direccionC);
        Trabajador trabajador1 = new Trabajador("Guia turistico", "Elias Figueroa", 27, direccionT);
        
        System.out.println(persona1);
        System.out.println(cliente1);
        System.out.println(trabajador1);
        
    }
    
}
